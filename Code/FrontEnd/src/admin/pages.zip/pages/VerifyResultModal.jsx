import { Dialog } from "@headlessui/react";
import { CheckCircle } from "lucide-react";
import axiosAdmin from "../../api/axiosAdmin";
import { useEffect, useRef } from "react";

export default function VerifyResultModal({
  open,
  onClose,
  data,
  data2,
  onResetData,
  setReloadTrigger,
  recipeId,
}) {
  const hasFetched = useRef(false);

  // 🔹 Fetch chi tiết công thức 1 lần khi modal mở
  useEffect(() => {
    if (!open || hasFetched.current) return;
    hasFetched.current = true;

    const handleReset = async () => {
      try {
        const updated = await axiosAdmin.get(`/recipe/detail/${recipeId}`);
        onResetData && onResetData(updated.data);
        setReloadTrigger((prev) => prev + 1);
      } catch (err) {
        console.error("❌ Lỗi khi load lại công thức:", err);
      }
    };

    handleReset();
  }, [open, recipeId, onResetData, setReloadTrigger]);

  // 🔹 Reset flag khi modal đóng
  useEffect(() => {
    if (!open) hasFetched.current = false;
  }, [open]);

  if (!data && !data2) return null;

  const { nutritionalInfo, dietaryTags, verificationInfo } = data || data2;

  if (!nutritionalInfo || !dietaryTags || !verificationInfo) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center"
    >
      <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-lg w-full p-6">
        <Dialog.Title className="text-2xl font-bold mb-3 flex items-center gap-2">
          <CheckCircle className="text-green-500" size={26} />
          Kết quả kiểm chứng công thức
        </Dialog.Title>

        {/* ✅ Thông tin dinh dưỡng */}
        <div className="mb-4">
          <h3 className="font-semibold text-gray-700 mb-2">
            Thông tin dinh dưỡng (trên 1 phần ăn)
          </h3>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm text-gray-600">
            <li>
              🔥 Calories: <b>{nutritionalInfo.calories}</b> kcal
            </li>
            <li>
              🍭 Đường: <b>{nutritionalInfo.sugar}</b> g
            </li>
            <li>
              🥔 Carbs: <b>{nutritionalInfo.carbs}</b> g
            </li>
            <li>
              🥑 Chất béo: <b>{nutritionalInfo.fat}</b> g
            </li>
            <li>
              🍗 Protein: <b>{nutritionalInfo.protein}</b> g
            </li>
            <li>
              🧂 Sodium: <b>{nutritionalInfo.sodium}</b> mg
            </li>
            <li>
              🩸 Cholesterol: <b>{nutritionalInfo.cholesterol}</b> mg
            </li>
            <li>
              🌾 Fiber: <b>{nutritionalInfo.fiber}</b> g
            </li>
          </ul>
        </div>

        {/* 🥦 Tag chế độ ăn */}
        <div className="mb-4">
          <h3 className="font-semibold text-gray-700 mb-2">
            Chế độ ăn phù hợp
          </h3>
          <div className="flex flex-wrap gap-2">
            <Tag label="Vegan" active={dietaryTags.isVegan} />
            <Tag label="Keto" active={dietaryTags.isKeto} />
            <Tag
              label="Thân thiện tiểu đường"
              active={dietaryTags.isDiabeticFriendly}
            />
            <Tag
              label="Thân thiện với thận"
              active={dietaryTags.isRenalFriendly}
            />
            <Tag
              label="Thân thiện tim mạch"
              active={dietaryTags.isHeartHealthy}
            />
          </div>
        </div>

        {/* 🧾 Thông tin xác minh */}
        <div className="border-t pt-3 text-sm text-gray-500">
          <p>
            <b>Nguồn:</b> {verificationInfo.source || "AI phân tích"}
          </p>
          <p>
            <b>Ngày xác minh:</b>{" "}
            {new Date(verificationInfo.verifiedAt).toLocaleString("vi-VN")}
          </p>
        </div>

        <div className="flex justify-end mt-5">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 rounded-xl hover:bg-gray-300 transition"
          >
            Đóng
          </button>
        </div>
      </div>
    </Dialog>
  );
}

function Tag({ label, active }) {
  return (
    <span
      className={`px-3 py-1 rounded-full text-sm font-medium border ${
        active
          ? "bg-green-100 text-green-700 border-green-300"
          : "bg-gray-100 text-gray-400 border-gray-200"
      }`}
    >
      {label}
    </span>
  );
}
