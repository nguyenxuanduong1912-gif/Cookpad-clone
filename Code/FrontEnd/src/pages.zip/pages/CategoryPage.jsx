// File: src/pages/CategoryPage.jsx

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axiosClient from "../api/axiosClient";
import { toast } from "react-toastify";
import Title from "../components/Title";
import RecipeCard from "../components/RecipeCard"; // Giả định bạn có component này
import { Button } from "@mui/material"; // Dùng Button của MUI cho tiện

function CategoryPage() {
  // Lấy slug từ URL (ví dụ: /category/mon-an-sang)
  const { slug } = useParams();
  const [categoryInfo, setCategoryInfo] = useState(null);
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // 🎯 HÀM FETCH DATA CÔNG THỨC VÀ INFO DANH MỤC
  useEffect(() => {
    if (!slug) return;

    setLoading(true);
    setError(null);

    // Cần hai API: 1. Lấy thông tin chi tiết danh mục; 2. Lấy danh sách công thức
    const fetchCategoryData = async () => {
      try {
        // 1. API lấy thông tin chi tiết danh mục (dùng slug để tìm)
        // Endpoint đề xuất: /categories/:slug
        // const infoRes = await axiosClient.get(`/categories/${slug}`);
        // const info = infoRes.data.category;
        // setCategoryInfo(info);

        // 2. API lấy công thức theo danh mục
        // Endpoint đề xuất: /recipes/by-category?slug=...
        const recipesRes = await axiosClient.get(
          `/recipes/by-category?slug=${slug}`
        );
        setRecipes(recipesRes.data.recipes);
      } catch (err) {
        console.error("Fetch Category Error:", err);
        const msg =
          err.response?.data?.message || `Không thể tải danh mục: ${slug}`;
        toast.error(msg);
        setError(msg);
        setRecipes([]);
        setCategoryInfo(null);
      } finally {
        setLoading(false);
      }
    };

    fetchCategoryData();
  }, [slug]);

  if (loading) {
    return (
      <main className="pt-[160px] pb-[70px] px-[120px] text-center">
        <p className="text-xl text-gray-600">
          Đang tải danh mục và công thức...
        </p>
      </main>
    );
  }

  if (error || !categoryInfo) {
    return (
      <main className="pt-[160px] pb-[70px] px-[120px] text-center">
        <Title text="Không tìm thấy Danh mục" />
        <p className="text-red-500 mt-4">Vui lòng kiểm tra lại đường dẫn.</p>
      </main>
    );
  }

  return (
    <main className="pt-[160px] pb-[70px]">
      {/* 1. HEADER / BANNER DANH MỤC */}
      <header
        className="relative h-64 bg-cover bg-center flex items-end p-10 mb-10"
        style={{
          // Dùng ảnh danh mục làm banner, nếu không có thì dùng màu nền
          backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url(${categoryInfo.image})`,
          backgroundColor: "#f93",
        }}
      >
        <div className="text-white z-10">
          <h1 className="text-5xl font-extrabold mb-2">{categoryInfo.name}</h1>
          <p className="text-lg font-light max-w-3xl opacity-90">
            {categoryInfo.description ||
              `Khám phá tất cả các công thức tuyệt vời thuộc danh mục ${categoryInfo.name}.`}
          </p>
        </div>
      </header>

      {/* 2. KHU VỰC CHÍNH - DANH SÁCH CÔNG THỨC */}
      <div className="px-[120px]">
        {/* Thanh bộ lọc (có thể mở rộng sau) */}
        <div className="flex justify-between items-center mb-6 border-b pb-4">
          <h2 className="text-2xl font-bold text-gray-700">
            {recipes.length} Công thức
          </h2>
          {/* Ví dụ Bộ lọc */}
          <div className="space-x-4">
            <span className="text-gray-500">Sắp xếp theo:</span>
            <Button
              size="small"
              variant="outlined"
              sx={{ color: "#f93", borderColor: "#f93" }}
            >
              Mới nhất
            </Button>
            <Button size="small" variant="outlined" color="primary">
              Phổ biến
            </Button>
          </div>
        </div>

        {/* Danh sách Công thức */}
        {recipes.length > 0 ? (
          <div className="grid grid-cols-4 gap-[24px]">
            {recipes.map((recipe) => (
              // Giả định RecipeCard nhận prop tương tự như khi hiển thị search results
              <RecipeCard
                key={recipe._id}
                src={recipe.image}
                href={`/recipe/${recipe.id_recipe}`}
                text={recipe.name}
                description={recipe.description}
                // Thêm các prop khác nếu cần (ví dụ: rating, author)
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-xl text-gray-500">
              Không có công thức nào thuộc danh mục **{categoryInfo.name}**. Hãy
              thử tìm kiếm!
            </p>
          </div>
        )}
      </div>
    </main>
  );
}

export default CategoryPage;
