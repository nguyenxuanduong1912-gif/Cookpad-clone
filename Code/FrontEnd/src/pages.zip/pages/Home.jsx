import axiosClient from "../api/axiosClient";
import { useEffect } from "react";
import { useState } from "react";
import Button from "../components/Button";
import TrendingCard from "../components/TrendingCard";
import Title from "../components/Title";
import RecentlyView from "../components/RecentlyView";
import RecipeCard from "../components/RecipeCard";
import { Modal } from "@mui/material";
import { Link, useOutletContext } from "react-router-dom";
import SearchRecentlyCard from "../components/SearchRecentlyCard";
import RecipeTag from "../components/RecipeTag";
import Tippy from "@tippyjs/react/headless";
import "tippy.js/dist/tippy.css";
import LoginCard from "../components/LoginCard";
import { useContext } from "react";
import { HistoryContext } from "../context/HistoryContext";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { userContext } from "../context/UserContext";
import SurveyModal from "../components/SurveyModal";
import RecipeSearchResult from "../components/RecipeSearchResult";
import SearchSuggestionDropdown from "../components/SearchSuggestionDropdown";
import MinimalIngredientSuggestion from "../components/MinimalIngredientSuggestion";
function Home() {
  const [searchResults, setSearchResults] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [open, setOpen] = useState(false);
  const [visible, setVisible] = useState(false);
  const [visible2, setVisible2] = useState(false);
  const [searchTrending, setSearchTrending] = useState();
  const [recentView, setRecentview] = useState([]);
  const [recentSearch, setRecentSearch] = useState([]);
  const [reset, setReset] = useState(false);
  const { user, setUser } = useContext(userContext);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [deleteState, setDeleteState] = useState({
    recentSearch: false,
    recentView: false,
  });
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  // const [openHistory, setOpenHistory] = useState(false);
  const [openLogin, setOpenLogin] = useState(false);
  const { openHistory, setOpenHistory } = useContext(HistoryContext);
  const { primaryInput, setPrimaryInput, dataSuggest, setDataSuggest } =
    useOutletContext();
  // File: Home.jsx (Thay thế khối useEffect tìm kiếm theo primaryInput)

  useEffect(() => {
    const input = primaryInput.trim();
    let isMounted = true;

    // Thoát ngay lập tức nếu input rỗng
    if (input === "") {
      setSearchResults([]);
      setVisible2(false);
      setLoading(false); // Đảm bảo loading tắt khi input rỗng
      return;
    }

    // 1. Thiết lập Debounce
    const delayDebounceFn = setTimeout(async () => {
      // Bắt đầu quá trình tìm kiếm sau khi hết thời gian debounce
      if (isMounted) {
        setLoading(true);
        setVisible2(false); // Ẩn kết quả cũ
      }

      try {
        const ingredients = input
          .split(",")
          .map((item) => item.trim())
          .filter((i) => i.length > 0);

        // Nếu không có nguyên liệu hợp lệ sau khi làm sạch, dừng lại
        if (ingredients.length === 0) {
          if (isMounted) {
            setSearchResults([]);
            setVisible2(false);
          }
          return;
        }

        // 2. Gọi API tìm kiếm chính
        const res = await axiosClient.post("/recipes/search-by-ingredients", {
          userId: user?.id,
          ingredients,
        });

        // 3. Cập nhật state nếu component vẫn còn mounted
        if (isMounted) {
          setSearchResults(res.data.recipes);
          // Chỉ hiển thị kết quả nếu có data
          setVisible2(res.data.recipes.length > 0);
        }
      } catch (error) {
        if (isMounted) {
          setSearchResults([]);
          toast.error(error.response?.data?.message || "Lỗi tìm kiếm xảy ra!");
          setVisible2(false);
        }
      } finally {
        // 4. Kết thúc loading
        if (isMounted) {
          setLoading(false);
        }
      }
    }, 400); // ⬅️ Độ trễ 300ms

    // 5. Cleanup function: Chạy trước khi useEffect chạy lại hoặc component unmount
    return () => {
      isMounted = false; // Vô hiệu hóa request cũ
      clearTimeout(delayDebounceFn); // Hủy bộ đếm thời gian debounce cũ
    };
    // Thêm các dependencies cần thiết
  }, [primaryInput, user, setLoading, setSearchResults, setVisible2]);
  const handleSearch = (keyword) => {
    setPrimaryInput(keyword);
    navigate(`/search?keyword=${primaryInput}`);
    setVisible(false);
  };
  const handleClose = () => {
    setIsOpen(false);
  };
  const handleSubmitSurvey = async (formData) => {
    try {
      const res = await axiosClient.post("/accounts/preferences", {
        healthCondition: formData.healthCondition,
        targetDiet: formData.dietaryGoal,
        excludeIngredients: formData.allergies,
        userId: user.id,
      });
      console.log(res.data.message);
    } catch (error) {}
  };
  useEffect(() => {
    const getRecipes = async () => {
      try {
        const res = await axiosClient.get("/recipes", {
          params: {
            keyword: "Hà nội",
          },
        });
        const res2 = await axiosClient.get("/recipes/categories");
        console.log(res2.data);
        if (user) {
          const res3 = await axiosClient.get("/recipes/recent-views");
          const res4 = await axiosClient.get("/search/history");
          const res5 = await axiosClient.get(`/accounts/${user.id}`);
          setIsOpen(!res5?.data?.user?.healthPreferences?.surveyCompleted);
          setRecentview(res3.data);
          setRecentSearch(res4.data);
        } else {
          setIsOpen(false);
        }
        setReset(false);
        setSearchTrending(res2.data);
        setRecipes(res.data.recipes || []);
      } catch (error) {
        console.error("Lỗi khi lấy recipes:", error);
      }
    };

    getRecipes();
  }, [reset, user]);

  return (
    <>
      <SurveyModal
        isOpen={isOpen}
        handleClose={handleClose}
        handleSubmitSurvey={handleSubmitSurvey}
      />
      <main className="text-[#606060]">
        <div className="px-[16px] mx-[40px]">
          {/* <div className="w-full mt-[75px] rounded-[6px] bg-[#81b000] p-[8px] flex items-center">
            <p className="m-auto text-white text-center">
              Đăng xuất thành công? Hẹn gặp lại
            </p>
            <Link>
              <img src="close.svg" alt="" className="" />
            </Link>
          </div> */}

          <div className="my-[56px] flex flex-col items-center gap-[24px] pt-[56px]">
            <img
              src="logo_cookpad.png"
              alt=""
              className="w-[224px] h-[61px] object-contain"
            />
            <div className="flex items-center gap-[10px]">
              <div className="flex text-[1.6rem] bg-[#f8f6f2] h-[48px] items-center px-[8px] rounded w-[400px]">
                <img src="search.svg" alt="" className="mr-[8px]" />
                <Tippy
                  appendTo={document.body}
                  zIndex={9999}
                  visible={visible2}
                  interactive={true}
                  onClickOutside={() => setVisible2(false)}
                  placement="bottom-end"
                  popperOptions={{
                    strategy: "fixed",
                  }}
                  render={(attrs) => (
                    <div
                      {...attrs}
                      className="w-[392px] max-h-[245px] bg-white rounded-[6px] overflow-y-auto"
                      tabIndex="-1"
                    >
                      {/* Hiển thị kết quả */}
                      <div className="mt-8">
                        {loading ? (
                          <p className="text-center">Đang tải kết quả...</p>
                        ) : (
                          <RecipeSearchResult
                            recipes={searchResults}
                            small={true}
                          />
                        )}
                      </div>
                    </div>
                  )}
                >
                  <input
                    type="text"
                    placeholder="Tìm tên món hay nguyên liệu"
                    name="query"
                    className="border-none outline-none caret-[#f93] w-full bg-transparent"
                    onFocus={(e) => {
                      setPrimaryInput(e.target.value);
                      setOpenHistory(true);
                    }}
                    onBlur={() => setOpenHistory(false)}
                    value={primaryInput}
                    onChange={(e) => {
                      setPrimaryInput(e.target.value);
                      setVisible2(true);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault(); // ngăn reload
                      }
                    }}
                  />
                </Tippy>
              </div>
              <Modal
                open={open}
                onClose={() => {
                  setOpen(false);
                }}
              >
                <div className="w-[390px] max-h-[500px] scrollbar-hide overflow-y-auto absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-60%] bg-white border-none outline-none p-[16px] rounded-[8px] text-[#606060]">
                  <div className="mb-[8px] flex items-center justify-end">
                    <img
                      src="close.svg"
                      alt=""
                      className="cursor-pointer"
                      onClick={() => {
                        setOpen(false);
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between mb-[8px]">
                    <h1 className="text-[1.8rem] font-semibold">
                      Tìm kiếm gần đây của bạn
                    </h1>

                    <Tippy
                      visible={deleteState.recentSearch}
                      interactive
                      onClickOutside={() =>
                        setDeleteState((pre) => ({
                          ...pre,
                          recentSearch: false,
                        }))
                      }
                      placement="bottom"
                      popperOptions={{
                        strategy: "fixed",
                      }}
                      render={(attrs) => (
                        <div
                          className="bg-white shadow-lg rounded-2xl w-[100px] p-[2px]"
                          tabIndex="-1"
                          {...attrs}
                        >
                          <div className="p-2 text-gray-700">
                            <div
                              className="py-2 hover:bg-gray-100 rounded-lg cursor-pointer flex items-center gap-[5px] text-[1.2rem]"
                              onClick={async () => {
                                await axiosClient.delete(
                                  "/search/search-history/all"
                                );
                                setReset(true);
                                setDeleteState((pre) => ({
                                  ...pre,
                                  recentSearch: false,
                                }));
                                setOpen(false);
                              }}
                            >
                              <img src="/bin.svg" alt="" /> Xóa tất cả
                            </div>
                          </div>
                        </div>
                      )}
                    >
                      <img
                        src="threedot.svg"
                        alt=""
                        className="cursor-pointer"
                        onClick={() =>
                          setDeleteState((pre) => ({
                            ...pre,
                            recentSearch: true,
                          }))
                        }
                      />
                    </Tippy>
                  </div>

                  <ul className="flex flex-col gap-[8px]">
                    {recentSearch?.history?.length === 0 ? (
                      <div className="mx-[45px] flex items-center justify-center flex-col">
                        <img
                          src="no_recipes.svg"
                          alt=""
                          className="mb-[16px]"
                        />
                        <p className="text-[2rem] font-semibold">
                          Không có lịch sử tìm kiếm
                        </p>
                        <p className="mt-[8px] text-[1.4rem] text-[#606060]">
                          Bạn chưa tìm kiếm món nào gần đây
                        </p>
                      </div>
                    ) : (
                      recentSearch?.history?.length > 0 &&
                      recentSearch.history.map((h, index) => (
                        <SearchRecentlyCard
                          key={index}
                          text={h.keyword}
                          minute={h.timeAgo}
                          href={`/search?keyword=${h.keyword}`}
                          handleDelete={async () => {
                            await axiosClient.delete(
                              "/search/search-history/one",
                              {
                                data: { keyword: h.keyword },
                              }
                            );
                            setReset(true);
                          }}
                        />
                      ))
                    )}

                    {/* <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} />
                    <SearchRecentlyCard text={"Thịt bò"} minute={"2"} /> */}
                  </ul>
                </div>
              </Modal>

              <Modal
                open={visible}
                onClose={() => {
                  setVisible(false);
                }}
              >
                <div className="w-[672px] max-h-[600px] scrollbar-hide overflow-y-auto absolute top-[50px] left-[50%] translate-x-[-50%]  bg-white border-none outline-none p-[16px] rounded-[8px] text-[#606060]">
                  <div className="mb-[8px] flex items-center justify-end">
                    <img
                      src="close.svg"
                      alt=""
                      className="cursor-pointer"
                      onClick={() => {
                        setVisible(false);
                      }}
                    />
                  </div>
                  {recentView?.recipes?.length > 0 && (
                    <div className="flex items-center justify-between mb-[8px]">
                      <h1 className="text-[2rem] font-semibold">
                        Món bạn mới xem gần đây
                      </h1>

                      <Tippy
                        visible={deleteState.recentSearch}
                        interactive
                        onClickOutside={() =>
                          setDeleteState((pre) => ({
                            ...pre,
                            recentSearch: false,
                          }))
                        }
                        placement="bottom"
                        popperOptions={{
                          strategy: "fixed",
                        }}
                        render={(attrs) => (
                          <div
                            className="bg-white shadow-lg rounded-2xl w-[100px] p-[2px]"
                            tabIndex="-1"
                            {...attrs}
                          >
                            <div className="p-2 text-gray-700">
                              <div
                                className="py-2 hover:bg-gray-100 rounded-lg cursor-pointer flex items-center gap-[5px] text-[1.2rem]"
                                onClick={async () => {
                                  await axiosClient.delete(
                                    "/recipes/viewed-recipes/all"
                                  );
                                  setReset(true);
                                  setDeleteState((pre) => ({
                                    ...pre,
                                    recentSearch: false,
                                  }));
                                  setVisible(false);
                                }}
                              >
                                <img src="/bin.svg" alt="" /> Xóa tất cả
                              </div>
                            </div>
                          </div>
                        )}
                      >
                        <img
                          src="threedot.svg"
                          alt=""
                          className="cursor-pointer"
                          onClick={() =>
                            setDeleteState((pre) => ({
                              ...pre,
                              recentSearch: true,
                            }))
                          }
                        />
                      </Tippy>
                    </div>
                  )}

                  <ul className="flex flex-col gap-[8px]">
                    {recentView?.recipes?.length === 0 && (
                      <div className="mx-[45px] py-[24px] flex items-center justify-center flex-col">
                        <img
                          src="no_recipes.svg"
                          alt=""
                          className="mb-[16px]"
                        />
                        <p className="text-[2rem] font-semibold">
                          Không có lịch sử xem món
                        </p>
                        <p className="mt-[8px] text-[1.4rem] text-[#606060]">
                          Bạn chưa xem món nào gần đây.
                        </p>
                      </div>
                    )}

                    <div className="py-[24px] flex flex-col gap-[10px]">
                      {recentView?.recipes?.length > 0 &&
                        recentView.recipes.map((r, index) => (
                          <RecipeTag
                            key={index}
                            text={r.name}
                            src={r.image}
                            ingredients={r.ingredients}
                            minute={r.cookTime}
                            person={r.servings}
                            avatar={r.author.avatar}
                            name={r.author.fullName}
                            bin={true}
                            handleDelete={async (e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              await axiosClient.delete(
                                "/recipes/viewed-recipes/one",
                                {
                                  data: { recipeId: r._id },
                                }
                              );
                              setReset(true);
                            }}
                            link={`/recipes/${r._id}`}
                          />
                        ))}

                      {/* <RecipeTag
                        text={"Khô Cá Trèn, Cá Chốt Chiên Chấm Mắm Me"}
                        src={
                          "https://img-global.cpcdn.com/recipes/59a1ec0de3d7812c/260x320f0.437322_0.5_1.0q50/kho-ca-tren-ca-ch%E1%BB%91t-chien-ch%E1%BA%A5m-m%E1%BA%AFm-me-recipe-main-photo.webp"
                        }
                        ingredients={
                          "me chín, tỏi băm, ớt hiểm băm nhỏ, nước mắm, muối, đường, khô cá trèn, khô cá chốt"
                        }
                        minute={10}
                        person={4}
                        avatar={
                          "https://img-global.cpcdn.com/users/cf350f88589e7075/48x48cq50/avatar.webp"
                        }
                        name={"Bòn bon"}
                      />
                      <RecipeTag
                        text={"Khô Cá Trèn, Cá Chốt Chiên Chấm Mắm Me"}
                        src={
                          "https://img-global.cpcdn.com/recipes/59a1ec0de3d7812c/260x320f0.437322_0.5_1.0q50/kho-ca-tren-ca-ch%E1%BB%91t-chien-ch%E1%BA%A5m-m%E1%BA%AFm-me-recipe-main-photo.webp"
                        }
                        ingredients={
                          "me chín, tỏi băm, ớt hiểm băm nhỏ, nước mắm, muối, đường, khô cá trèn, khô cá chốt"
                        }
                        minute={10}
                        person={4}
                        avatar={
                          "https://img-global.cpcdn.com/users/cf350f88589e7075/48x48cq50/avatar.webp"
                        }
                        name={"Bòn bon"}
                      />
                      <RecipeTag
                        text={"Khô Cá Trèn, Cá Chốt Chiên Chấm Mắm Me"}
                        src={
                          "https://img-global.cpcdn.com/recipes/59a1ec0de3d7812c/260x320f0.437322_0.5_1.0q50/kho-ca-tren-ca-ch%E1%BB%91t-chien-ch%E1%BA%A5m-m%E1%BA%AFm-me-recipe-main-photo.webp"
                        }
                        ingredients={
                          "cà pháo Thái (3 trái), cà pháo Việt (5 trái), cà đắng, củ nén, ớt đỏ (ớt có thể thêm nếu thích ăn cay nhiều), ngò gai, lá é, khô cá sặc (bạn có thể thay nguyên liệu này bằng các loại khô khác hoặc cá hấp giỏ cũng được), muối, bột ngọt, nước cốt chanh (nếu không thích ăn chua thì không dùng)"
                        }
                        minute={10}
                        person={4}
                        avatar={
                          "https://img-global.cpcdn.com/users/cf350f88589e7075/48x48cq50/avatar.webp"
                        }
                        name={"Bòn bon"}
                      /> */}
                    </div>
                  </ul>
                </div>
              </Modal>

              <Button
                text="Tìm Kiếm"
                color="#f93"
                px="24px"
                py="12px"
                textColor={"#fff"}
                borderColor="#f93"
                onClick={() => handleSearch()}
              />
            </div>

            <section className="w-full">
              <div>
                {/* <div className="text-[#4a4a4a] flex items-center justify-between mb-[16px]">
                  <h1 className="text-[1.8rem] font-semibold">
                    Từ khóa thịnh hành
                  </h1>
                  <span className="text-[1.2rem]">Cập nhật 04:28</span>
                </div> */}

                <Title text={"Danh mục món ăn"} time={""} />
                <div className="grid grid-cols-4 gap-x-[16px] gap-y-[8px] mb-[24px]">
                  {searchTrending?.categories?.length > 0 &&
                    searchTrending.categories.map((s, index) => (
                      <TrendingCard
                        text={s.name}
                        src={s.image}
                        href={`/search?keyword=${s.slug}`}
                      />
                    ))}
                  {/* 
                  <TrendingCard
                    text={"Thực đơn món ngon mỗi ngày"}
                    src={
                      "https://img-global.cpcdn.com/recipes/ccda21675c3ae602/560x192cq50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Cá"}
                    src={
                      "https://img-global.cpcdn.com/recipes/c9e71403ea8a4fea/560x192cq50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Bánh"}
                    src={
                      "https://img-global.cpcdn.com/recipes/3129e01e8e16efe3/560x192f0.502029_0.5_1.0q50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Trứng"}
                    src={
                      "https://img-global.cpcdn.com/recipes/1cf68e76e462eb8c/560x192f0.500306_0.5_1.0q50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Đậu hũ"}
                    src={
                      "https://img-global.cpcdn.com/recipes/af4a00ea96579b35/560x192cq50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Ức gà sốt"}
                    src={
                      "https://img-global.cpcdn.com/recipes/8349e5d53c3f7298/560x192f0.5_0.500105_1.0q50/photo.webp"
                    }
                  />
                  <TrendingCard
                    text={"Lá lốt"}
                    src={
                      "https://img-global.cpcdn.com/recipes/add2d6160ccdf800/560x192cq50/photo.webp"
                    }
                  /> */}
                </div>
                {recentView?.recipes?.length > 0 && (
                  <Title
                    text={"Món bạn mới xem gần đây"}
                    arrow="arrow.svg"
                    handleOnCLick={() => {
                      setVisible(true);
                    }}
                  />
                )}

                <div className="grid grid-cols-6 gap-[16px]">
                  {recentView?.recipes?.length > 0 &&
                    recentView.recipes
                      .slice(0, 6)
                      .map((r, index) => (
                        <RecentlyView
                          key={index}
                          src={r.image}
                          avatar={r.author.avatar}
                          name={r.author.fullName}
                          decription={r.name}
                          href={`/recipes/${r._id}`}
                        />
                      ))}
                </div>
              </div>
              <div className="my-[24px]">
                <Title text={"Gói Premium"} icon={"premium2.svg"} />
              </div>

              <div className="grid grid-cols-3 gap-[16px] mb-[24px]">
                <RecipeCard
                  src={
                    "https://global-web-assets.cpcdn.com/assets/premium/premium_feature/hall_of_fame_recipes-c88c0c3e9b0a9baec1fcd84c066cc9c78eb79f44d4848ba4bac890e5e90e3786.webp"
                  }
                  href={"/"}
                  text={"Top Món Có Nhiều Cooksnap Nhất"}
                  description={"Công thức đã nhận được hơn 10 cooksnap"}
                />

                <RecipeCard
                  src={
                    "https://global-web-assets.cpcdn.com/assets/premium/premium_feature/meal_plans-682dc62344237d32f8878778b750c3d1df25892066375df420b5de4b6c24432f.webp"
                  }
                  href={"/"}
                  text={"Thực Đơn Premium"}
                  description={
                    "Thực đơn hàng tuần với những nguyên liệu theo mùa"
                  }
                />

                <RecipeCard
                  src={
                    "https://global-web-assets.cpcdn.com/assets/premium/premium_feature/access_rankings-a00e64c1f8635b8c1c34eaf988550afe8a389e92e5940ce77d5314833fdd5703.webp"
                  }
                  href={"/"}
                  text={"Top Món Được Xem Nhiều Nhất"}
                  description={
                    "Những công thức có lượt xem nhiều nhất, cập nhật mỗi ngày"
                  }
                />
              </div>
              {recentSearch?.history?.length > 0 && (
                <Title
                  text={"Recent searches"}
                  arrow={"arrow.svg"}
                  handleOnCLick={() => {
                    setOpen(true);
                  }}
                />
              )}

              <div className="grid grid-cols-3 gap-[16px]">
                {recentSearch?.history?.length > 0 &&
                  recentSearch.history
                    .slice(0, 3)
                    .map((h, index) => (
                      <RecipeCard
                        key={index}
                        src={h.image}
                        href={`/search?keyword=${h.keyword}`}
                        text={h.keyword}
                        description={h.timeAgo}
                      />
                    ))}
              </div>
            </section>
          </div>
        </div>
      </main>
    </>
  );
}

export default Home;
